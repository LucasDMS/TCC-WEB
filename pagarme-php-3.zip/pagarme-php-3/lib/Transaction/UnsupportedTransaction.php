<?php

namespace PagarMe\Sdk\Transaction;

use PagarMe\Sdk\PagarMeException;

class UnsupportedTransaction extends PagarMeException
{
}
